﻿using UnityEngine;
using System.Collections;

public class EarthOptionsGUISimple : MonoBehaviour {


	private float earthRotationSpeed = 2.0f;


	public float labelWidth = 160;

	// Use this for initialization
	void Start () {
		
	}

	void Update()
	{
		transform.Rotate(new Vector3(0, Time.deltaTime * earthRotationSpeed, 0));
	}
}
