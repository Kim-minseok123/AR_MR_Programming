﻿using UnityEngine;

public class RevealingLightManipulation : MonoBehaviour {
    
    public float rotSpeed = 5.0f;

    private void Update()
    {
        transform.Rotate(new Vector3(0, rotSpeed * Time.deltaTime, 0));
    }
   
}
