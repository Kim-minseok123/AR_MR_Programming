﻿using UnityEngine;
using TMPro;

public class ContentTextController : MonoBehaviour
{
    public Transform target;
    public string[] text;
    private int index;
    public TextMeshPro ContentText;
    public static ContentTextController instance;
    // Start is called before the first frame update
    void Awake()
    {
        if(instance != null)
            Destroy(instance);
        instance = this;
        index = -1;
    }

    void Update()
    {
        transform.rotation = Quaternion.LookRotation(transform.position - target.position);
    }

    public void NextText() 
    {
        if (index == text.Length - 1) {
            return;
        }
        index++;
        ContentText.text = text[index];
    }
    public void PrevText()
    {
        if (index == 0) { 
            return;
        }
        index--;
        ContentText.text = text[index];
    }
}
