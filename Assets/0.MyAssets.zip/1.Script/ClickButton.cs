﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickButton : MonoBehaviour
{
    // Start is called before the first frame update
    public void PreviousText() {
        ContentsController.instance.PrevText();
    }
    public void NextText() {
        ContentsController.instance.NextText();
    }

    
}
