﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickButton : MonoBehaviour
{
    // Start is called before the first frame update
    public void PreviousText() {
        ContentTextController.instance.PrevText();
    }
    public void NextText() {
        ContentTextController.instance.NextText();
    }

    
}
