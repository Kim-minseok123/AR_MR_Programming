﻿using UnityEngine;
using TMPro;
using System.Collections;
using System.Collections.Generic;

public class ContentsController : MonoBehaviour
{
    private string[] text;
    private int index;
    public GameObject Earth;
    public TextMeshPro ContentText;
    public static ContentsController instance;
    public GameObject WaterPlane;
    public GameObject Arctic;
    public Animator ArcticAni;
    // Start is called before the first frame update
    void Awake()
    {
        if(instance != null)
            Destroy(instance);
        instance = this;
        index = -1;
        text = new string[9];
        text[0] = "지구는 생명체가 살기에 최적화가 된 행성입니다.";
        text[1] = "이러한 지구는 인류의 미래를 위해 보존해야합니다.";
        text[2] = "하지만 보다시피 지구는 밤이되면 많은 에너지를 소비합니다.";
        text[3] = "코로나19 사태로 인해 2020년 0.7% 감소됐던 세계 전력 소비량이 2021년 +5.5% 증가하면서 2019년 수준을 +4.8% 웃돌았습니다.";
        text[4] = "이러한 전기 사용량의 증가 뿐만 아니라 여러 원인들로 인해 지구온난화가 급속도로 진행됩니다.";
        text[5] = "여기가 북극이라고 해봅시다.";
        text[6] = "매년 빙하는 ~~씩 녹아 ~~씩 사라지고 있습니다.";
        text[7] = " 점점 빙하는 사라지고 있고 동물들 역시 살 공간이 사라집니다.";
        text[8] = "우리는 이를 막아야합니다.";
    }

    public void NextText() 
    {
        if (index == text.Length - 1) {
            return;
        }
        index++;
        if (index == 5)
        {
            //스케일이 점점 작아지면서 지구 사라짐.
            StartCoroutine(Smallsize(Earth, 0.5f));
            //물 나타남.
            StartCoroutine(Bigsize(WaterPlane, 0.2f));
            //빙하 나타남.
            Arctic.SetActive(true);
        }
        else if (index == 6) {
            //빙하 흩어지는 애니메이션
            ArcticAni.SetTrigger("Broken");
        }
        ContentText.text = text[index];
    }
    public void PrevText()
    {
        if (index == 0 || index == -1) { 
            return;
        }
        index--;
        if (index == 4) {
            //스케일 점점 커지면서 지구 나타남.
            StartCoroutine(Bigsize(Earth, 0.5f));
            //물 사라짐.
            StartCoroutine(Smallsize(WaterPlane, 0.2f));
            Arctic.SetActive(false);
        }
        else if (index == 5) {
            ArcticAni.SetTrigger("Combine");
        }
        ContentText.text = text[index];
    }

    private IEnumerator Smallsize(GameObject obj, float sizex) {
        while (obj.transform.localScale.x >= 0.001) {
            yield return null;
            //특정 오브젝트의 스케일을 한 프레임당 10%씩 줄임
            obj.transform.localScale *= 0.9f; 
        }
        obj.SetActive(false);
    }
    private IEnumerator Bigsize(GameObject obj, float sizex)
    {
        obj.SetActive(true);
        while (obj.transform.localScale.x <= sizex)
        {
            yield return null;
            //특정 오브젝트의 스케일을 sizex까지 한 프레임당 10%씩 늘림
            obj.transform.localScale *= 1.1f;
        }
    }
}
